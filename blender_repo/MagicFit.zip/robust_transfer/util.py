# This file is part of Robust Weight Transfer for Blender.
#
# Copyright (C) 2025 sentfromspacevr
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Attribution: Developed by sentfromspacevr (https://github.com/sentfromspacevr)
#
# Changed for Magic Fit (2026-09): SciPy is imported on first use, so the
# sidebar and the operators' poll functions can use these helpers without loading it,
# and there's no draw_debug_vertex_colors (Visualize Rejected Weights). 2026-10: no mesh adjacency
# helpers, which only the standalone add-on's smoothing used.

import numpy as np
import bpy


def get_obj_arrs_world(object: bpy.types.Object):
    mesh: bpy.types.Mesh = object.data
    mesh.calc_loop_triangles()

    vertices = np.empty((len(mesh.vertices), 3), dtype=np.float32)
    indices = np.empty((len(mesh.loop_triangles), 3), dtype=np.int64)
    normals = np.empty((len(mesh.vertices), 3), dtype=np.float32)

    mesh.vertices.foreach_get("co", vertices.reshape(-1))
    mesh.loop_triangles.foreach_get("vertices", indices.reshape(-1))
    # mesh.vertex_normals.foreach_get('vector', normals.reshape(-1))
    mesh.vertices.foreach_get('normal', normals.reshape(-1))
    
    world_matrix = np.array(object.matrix_world)
    ones = np.ones((vertices.shape[0], 1))
    
    vertices_4d = np.hstack((vertices, ones))
    world_vertices_4d = (world_matrix @ vertices_4d.T).T
    world_vertices_4d = np.ascontiguousarray(world_vertices_4d, dtype=np.float32)
    world_vertices = world_vertices_4d[:,:3] / world_vertices_4d[:, 3][:, np.newaxis]
    
    world_normals = (np.linalg.inv(world_matrix[:3, :3]).T @ normals.T).T
    world_normals = np.ascontiguousarray(world_normals, dtype=np.float32)
    
    return world_vertices, indices, world_normals


def get_group_arr(obj: bpy.types.Object, group_name):
    mesh: bpy.types.Mesh = obj.data
    if not isinstance(mesh, bpy.types.Mesh): return
    group_index = obj.vertex_groups[group_name].index
    arr = np.zeros(len(mesh.vertices), dtype=np.float32)
    for i, v in enumerate(mesh.vertices):
        for g in v.groups:
            if g.group == group_index:
                arr[i] = g.weight
    return arr


def get_groups_arr(obj: bpy.types.Object, include_groups: list[bool]=None):
    mesh: bpy.types.Mesh = obj.data
    if not isinstance(mesh, bpy.types.Mesh): return

    arr = np.zeros((len(mesh.vertices), len(obj.vertex_groups)), dtype=np.float32)
    for i, v in enumerate(mesh.vertices):
        current_vertex = arr[i]
        for g in v.groups:
            if g.group >= arr.shape[1]:
                print(f"WARNING: group index {g.group} out of bounds ({arr.shape[1]} vertex groups) for vertex {i}")
                continue
            if include_groups and include_groups[g.group]:
                current_vertex[g.group] = g.weight
            elif not include_groups:
                current_vertex[g.group] = g.weight
    return arr


TOPOLOGY_MODS = {
    'ARRAY',
    'BEVEL',
    'BOOLEAN',
    'BUILD',
    'DECIMATE',
    'EDGE_SPLIT',
    'EXPLODE',
    'FLUID',
    'MASK',
    'MESH_TO_VOLUME',
    'MIRROR',
    'MULTIRES',
    'NODES',
    'OCEAN',
    'PARTICLE_INSTANCE',
    'REMESH',
    'SCREW',
    'SKIN',
    'SOLIDIFY',
    'SUBSURF',
    'TRIANGULATE',
    'VOLUME_TO_MESH',
    'WELD',
    'WIREFRAME'
}


def has_modifier(obj: bpy.types.Object, *mod_types):
    if obj and obj.type == 'MESH' and obj.modifiers:
        return any(mod.show_viewport and mod.type in mod_types for mod in obj.modifiers)
    return False


# TODO: source object required to have armature modifier
# throw exceptions
def is_vertex_group_deform_bone(obj, group_name):
    armature_mod = None
    for mod in obj.modifiers:
        if mod.type == 'ARMATURE':
            armature_mod = mod
            break

    if not armature_mod or not armature_mod.object or armature_mod.object.type != 'ARMATURE':
        return False

    armature_obj = armature_mod.object
    bone = armature_obj.data.bones.get(group_name)

    if bone and bone.use_deform:
        return True

    return False


def is_group_valid(vertex_groups, group_name):
    return len(group_name) > 0 and group_name in vertex_groups
