# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "Magic Fit",
    "author": "Luci_xiv",
    "description": "Copy weights from a body, fit, resize and line up meshes on it, weight hair and custom faces like the game's, preview Customize+ templates, and repair meshes: relax stretched textures, close rips, rebuild topology, normals and UVs",
    "version": (1, 1, 5),
    "blender": (5, 2, 0),
    "location": "3D Viewport > Sidebar (N) > Magic Fit tab, and the Weight Paint / Edit Mode toolbars",
    "doc_url": "https://github.com/link-0402/MagicFit",
    "category": "Mesh",
}

# Blender runs this module again, in place, when the add-on is updated or reloaded. Then the other
# modules are reloaded too, in dependency order. (Every version so far has had `properties`.)
_reloading = "properties" in locals()

from . import properties, tabs, painting, fitting, moving, mending, straighten, goals, skirting, heeling, hairing, smoothing, squishing, connecting, gamefiles, facedata, facing, relaxing, resizing, refining, sizing, api, lineup, hairlineup, clipping, operators, tool  # noqa: E402
from . import robust_transfer, cplus, resurface, preferences  # noqa: E402

if _reloading:
    import importlib
    for _module in (properties, tabs, painting, fitting, moving, mending, straighten, goals, skirting, heeling, hairing,
                    smoothing, squishing, connecting, gamefiles, facedata, facing, relaxing, resizing, refining, sizing, api, lineup,
                    hairlineup, clipping, operators, tool, robust_transfer, cplus, resurface, preferences):
        importlib.reload(_module)

_modules = (properties, tabs, operators, tool, clipping, robust_transfer, cplus, resurface, preferences)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()
    painting.clear_cache()
    smoothing.clear_cache()
    squishing.clear_cache()
    hairing.clear_cache()
    fitting.BodySurface.clear_cache()
    fitting.FitStroke.clear_cache()
    operators.clear_follow_cache()
    facing.clear_cache()
